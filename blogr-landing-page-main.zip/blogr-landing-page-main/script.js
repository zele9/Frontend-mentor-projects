var navBtn = document.querySelector('#nav-menu');
var navBar = document.querySelector('#nav-list');

navBtn.addEventListener("click", () => {
    navBar.style.display = 'block';
    navBtn.src = './images/icon-close.svg';
  });

  navBtn.addEventListener('dblclick', () => {
    // Do something when the nav bar is clicked
    navBar.style.display = 'none';
    navBtn.src = './images/icon-hamburger.svg';
  });